import os

os.environ["ENABLE_AUTH"] = "false"
