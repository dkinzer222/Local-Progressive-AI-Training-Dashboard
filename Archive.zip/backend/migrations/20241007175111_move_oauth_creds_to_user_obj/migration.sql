-- AlterTable
ALTER TABLE "User" ADD COLUMN     "metadata" JSONB;
