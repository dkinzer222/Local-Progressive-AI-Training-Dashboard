-- AlterTable
ALTER TABLE "AgentGraphExecution" ADD COLUMN "stats" TEXT;

-- AlterTable
ALTER TABLE "AgentNodeExecution" ADD COLUMN "stats" TEXT;
