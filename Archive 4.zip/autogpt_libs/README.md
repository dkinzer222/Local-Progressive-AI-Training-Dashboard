# AutoGPT Libs

This is a new project to store shared functionality across different services in NextGen AutoGPT (e.g. authentication)
