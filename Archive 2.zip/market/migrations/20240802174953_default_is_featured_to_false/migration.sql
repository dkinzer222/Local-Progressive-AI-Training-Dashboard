-- AlterTable
ALTER TABLE "FeaturedAgent" ALTER COLUMN "is_featured" SET DEFAULT false;
